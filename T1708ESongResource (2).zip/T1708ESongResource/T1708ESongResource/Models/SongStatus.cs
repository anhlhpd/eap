﻿namespace T1708ESongResource.Models
{
    public enum SongStatus
    {
        Active = 1,
        Deactive = 0
    }
}