﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using T1708EOauth2Server.Data;
using T1708EOauth2Server.Models;

namespace T1708EOauth2Server.Controllers
{
    public class AuthorizationController : Controller
    {
        private readonly T1708EOauth2ServerContext _context;

        private readonly Dictionary<int, CredentialScope> _credentialScopes = new Dictionary<int, CredentialScope>()
        {
            {
                1,
                new CredentialScope()
                {
                    Id = 1,
                    Name = "Basic",
                    Icon = "https://cdn4.iconfinder.com/data/icons/eldorado-mobile/40/info_3-128.png",
                    Description = "Mô tả ngắn gọn về quyền ở trên."
                }

            },
            {
                2,
                new CredentialScope()
                {
                    Name = "Song",
                    Icon = "https://cdn3.iconfinder.com/data/icons/watchify-v1-0-32px/32/music-note-128.png",
                    Description = "Quản lý thông tin bài hát của người dùng."
                }

            },
            {
                3,
                new CredentialScope()
                {
                    Name = "Photo",
                    Icon = "http://icons.iconarchive.com/icons/designcontest/outline/256/Camera-icon.png",
                    Description = "Quản lý thông tin photo."
                }

            }

        };
        public AuthorizationController(T1708EOauth2ServerContext context)
        {
            _context = context;
        }
        public IActionResult Consent(int clientId, string scopes)
        {
            var currentApp = _context.RegisterApplication.SingleOrDefault(ra => ra.Id == clientId);
            if (currentApp == null)
            {
                Response.StatusCode = (int)(HttpStatusCode.Forbidden);
                return new JsonResult(HttpStatusCode.Forbidden.ToString());           
            }

            var scopeIds = scopes.Split(",");
            List<CredentialScope> listRequestScopes = new List<CredentialScope>();
            foreach (var strId in scopeIds)
            {
                var id = Int32.Parse(strId);
                if (!_credentialScopes.ContainsKey(id))
                {
                    Response.StatusCode = (int)(HttpStatusCode.NotFound);
                    return new JsonResult(HttpStatusCode.NotFound.ToString());
                }
                listRequestScopes.Add(_credentialScopes[id]);
            }

            ViewData["currentApp"] = currentApp;
            ViewData["listRequestScopes"] = listRequestScopes;
            ViewData["scopes"] = scopes;
            return View();
        }

    }
}