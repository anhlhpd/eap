﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using T1708EOauth2Server.Models;
using T1708EOauth2Server.Data;

namespace T1708EOauth2Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly T1708EOauth2ServerContext _context;

        
        public AuthenticationController(T1708EOauth2ServerContext context)
        {
            _context = context;
        }

        public IActionResult CheckToken(string accessToken)
        {
           var credential = _context.Credential.SingleOrDefault(t => t.AccessToken == accessToken);
            if (credential == null || !credential.IsValid())
            {
                Response.StatusCode = (int) HttpStatusCode.Forbidden;
                return new JsonResult("Invalid token");
            }
            else
            {
                return new JsonResult(credential);
            }
        }


        // POST: api/Authentication
        [HttpPost]
        public IActionResult Login(LoginInformation account)
        {
            var loginSuccess = false;
            var existAccount = _context.Account.SingleOrDefault(a => a.Email == account.Email);
            if (existAccount != null)
            {
                if (existAccount.Password == SecurityHelper.PasswordHandle.GetInstance().EncryptPassword(account.Password, existAccount.Salt))
                {
                    loginSuccess = true;
                }
            }

            if (loginSuccess)
            {
                var credential = new Credential(existAccount.Id);
                _context.Credential.Add(credential);
                _context.SaveChanges();
                Response.StatusCode = 200;
                return new JsonResult(credential);
            };
            Response.StatusCode = 403;
            return new JsonResult("Invalid information");
        }
       
    }
}